# SYSTEMS & SNUGGLE
# PREMIUM PAPER-CUT DOCUMENTARY EXPLAINER
## CODEX + REMOTION PRODUCTION PROMPT V2.0

### PROJECT

**Title:** Before 2027, Keep, Fix or Cancel Your Business Tools

**Brand:** Systems & Snuggle

**Website:** https://systemsnsnuggle.com/

**Source subtitle file:** `Edit Phase 1.srt`

**Source video:** Locate the separately supplied original video file in the Remotion project.

**Original SRT timeline:** 00:00.360–01:27.820

**Original SRT cues:** 31

**Primary format:** Vertical 9:16, 1080 × 1920

**Frame rate:** 30 fps final output, with optional 12 fps-style paper animation

**Output:** H.264 MP4, AAC audio, editable Remotion project, corrected SRT, animation timeline, and audio cue sheet.

---

# 1. CREATIVE ROLE

You are the creative director, editorial motion designer, documentary editor, sound designer, and senior Remotion engineer for Systems & Snuggle.

Create a beautifully animated paper-collage documentary explainer inspired by the editorial storytelling language of Vox videos.

This is NOT primarily a talking-head video.

The original speaker's voice should guide an almost continuous visual story composed of:

- Handmade construction-paper animations
- Layered editorial paper collages
- Torn and imperfect paper edges
- Animated document clippings
- Highlight sweeps
- Paper-cut illustrations
- Hand-drawn circles and arrows
- Tactile stop-motion movement
- Subtle 2.5D parallax
- Animated explanatory diagrams
- Paper labels, stamps, folders and checklists
- Selectively displayed square narrator footage
- Carefully synchronized music and sound effects

Make the production feel like a sophisticated editorial documentary created by a professional motion-design studio.

The visuals should feel physical, tactile, slightly imperfect, sophisticated, and rich with meaningful information.

Never use effects merely to fill the screen.

Do not copy Vox's official logo, trademarked visual identity, footage, or individual compositions.

---

# 2. CENTRAL VISUAL STORY

The video explains a simple idea:

**Business owners should review their existing tools and decide what to KEEP, FIX, or CANCEL before 2027.**

Create one recurring visual anchor:

A physical-looking collection of software application cards scattered across a textured paper desk.

The cards represent a business owner's current software stack.

At the beginning, the stack is messy and disconnected.

As the video progresses, the cards are gradually categorized into three paper folders:

KEEP
FIX
CANCEL

By the end, the same messy stack has become organized.

This visual transformation must carry the entire documentary.

Use the anchor-and-bridge storytelling structure:

1. Present an intriguing visual problem.
2. Let the narrator explain why it matters.
3. Return to the recurring visual anchor.
4. Reveal the next part of the explanation.
5. Build toward the three decisions.
6. Finish by showing the larger insight.

Do not invent statistics, financial savings, specific client results, or factual claims not supported by the narration.

---

# 3. THE PAPER ANIMATION LOOK

The video should look as though it was constructed on a physical animation table using paper, photographs, markers, scissors, and printed documents.

## Paper textures

Use:
- Warm off-white paper
- Fibrous construction paper
- Recycled paper
- Slightly worn cardstock
- Light halftone printing
- Photocopy textures
- Subtle paper grain
- Occasional imperfect print registration
- Subtle shadow between paper layers

No plain, empty, sterile digital backgrounds.

However, retain enough clean space for readability.

Paper textures must be subtle enough that typography and diagrams remain crisp.

## Paper edges

Create realistic:
- Torn edges
- Irregular cut edges
- Slight asymmetry
- Paper corner folds
- Subtle thickness
- Naturally varied shadows

Avoid repetitive identical torn-edge templates.

Use controlled, seeded randomness for handmade imperfections.

## Layer depth

Each collage should contain several independently animated layers.

Example:

Layer 1: Background paper
Layer 2: Decorative printed texture
Layer 3: Paper photograph or software card
Layer 4: Text or annotation
Layer 5: Hand-drawn highlight
Layer 6: Foreground paper fragment or shadow

Use mild parallax to establish depth.

Do not make paper objects appear as floating glossy 3D objects.

## Motion personality

Paper objects should behave like physical pieces of paper placed and moved by hand.

Possible motions:
- Slide onto desk
- Drop lightly into place
- Rotate 1–4 degrees
- Settle after contact
- Lift slightly with a shadow change
- Flip like a card
- Stack
- Unstack
- Fold
- Reveal beneath another sheet
- Tear away
- Receive a rubber stamp
- Slide into a folder
- Connect using a hand-drawn line

The movement should have a tactile, handcrafted quality.

---

# 4. FRAME RATE AND ANIMATION TIMING

The final video must remain smooth and compatible with social media.

Use a 30 fps final composition by default.

For selected paper-cut elements, simulate animating on twos or threes using deliberate stepped animation.

A paper element can update around 10–15 times per second to create a handmade stop-motion feeling.

IMPORTANT:

Do not reduce the frame rate of the original narrator video.

Do not make all animation choppy.

Use stepped movement for:
- Small paper cutouts
- Rubber stamps
- Collage repositioning
- Handcrafted decorative objects
- Selected paper transitions

Use smooth movement for:
- Camera pans
- Major composition transitions
- Important text reveals
- Animated workflow connector lines
- Narrator footage
- Slow parallax

Use deterministic Remotion animations based on frame timing.

Avoid browser timers, non-seeded randomness, and uncontrolled CSS animations.

Create a reusable PaperMotion component with configurable:
- Stepped or smooth animation
- Entrance direction
- Entrance delay
- Rotation
- Scale
- Shadow
- Easing
- Paper movement intensity

---

# 5. NARRATOR VIDEO WINDOW

THIS IS AN IMPORTANT CREATIVE REQUIREMENT.

The speaker's original video does not need to fill the screen.

Treat the speaker as the documentary narrator.

Her voice should continue naturally while the paper-collage animation occupies most of the screen.

Display her actual face selectively inside a small square video window.

## Narrator window design

Create a reusable SquareNarrator component.

Suggested defaults:
- Square 1:1 aspect ratio
- Approximately 20–28% of composition width
- Adjustable position
- Gentle paper border
- Slightly irregular or deckled frame
- Soft realistic shadow
- Optional paper tape or printed-photo styling
- Subtle 1–2 degree rotation
- Natural video playback inside the window

The exact size should adapt to the composition and the importance of the surrounding graphics.

Available positions:
- Top left
- Top right
- Bottom left
- Bottom right
- Center for deliberate emphasis

Use safe-area-aware positioning.

Never cover important captions or diagrams.

## When to show the speaker

Show her face:
- During witty punchlines
- During personal references
- When establishing expertise or credibility
- When her facial expression adds meaning
- During selected transitions
- Near the closing teaser

Do not show her face:
- During most detailed workflow demonstrations
- When paper animations need the entire frame
- When the narrator window would distract from evidence
- Simply to fill empty space

The video should be visually interesting even when the narrator window is absent.

Do not fabricate, redraw, or alter her face.

Use only her original footage.

When the window is visible, crop carefully to retain her face and natural expressions.

Preserve original speech audio while hiding or showing the video independently.

Avoid double audio caused by multiple copies of the source video.

---

# 6. TYPOGRAPHY AND HIGHLIGHT ANIMATIONS

Use editorial documentary typography.

Prefer:
- Bold, condensed sans-serif headlines
- Clean informational text
- Readable labels
- Occasional typewriter-style accents
- Subtle printed-paper imperfections

Use the actual verified Systems & Snuggle typography when available.

Do not use decorative fonts that impair readability.

## Highlight sweep

Create a reusable HandDrawnHighlight component.

The highlight should:
- Appear like a physical marker moving across paper
- Follow the shape of the intended phrase
- Use a slightly imperfect edge
- Reveal progressively
- Remain behind the words
- Preserve text legibility
- Match the narration timing

Use the verified brand accent rather than automatically copying Vox yellow.

## Hand-drawn annotations

Create reusable:
- Animated circle
- Underline
- Arrow
- Bracket
- Number marker
- Sticky note
- Paper label
- Rubber stamp

Draw annotations using vector paths and animated strokes.

Avoid simply fading complete annotations into place.

---

# 7. EXACT SCENE PLAN BASED ON SRT

Use the original SRT as the initial timing reference.

After inspecting the original video and verifying audio, correct timing where necessary.

## SCENE 1 — THE SOFTWARE PROBLEM
00:00.360–00:10.600

Narration:

"You're paying for software to make your business easier but somehow you're still doing all the work, right? So are these apps your employees or are you theirs?"

Visuals:

Open on a full-screen textured paper composition.

A printed invoice marked "SOFTWARE SUBSCRIPTIONS" lands on the desk.

Several paper software cards stack rapidly.

Animate a paper cutout cursor repeatedly transferring documents between cards.

Reveal a large hand-drawn question:

"WHO'S DOING THE WORK?"

On "are these apps your employees or are you theirs?" briefly display the speaker inside a square photo-like window.

Make this moment playful.

A large paper label reading "THE BOSS?" flips between a business owner illustration and software cards.

Use a short comedic pause or visual hold when the narration permits.

Sound:
- Paper drop
- Soft mouse clicks
- Light typing
- One understated comedic accent

Music:
Minimal curious documentary beat.

## SCENE 2 — MORE TOOLS ≠ BETTER SYSTEMS
00:11.260–00:21.540

Narration explains years of business-backend experience and why more tools do not necessarily mean better operations.

Visuals:

Create a tabletop collage of software cards labeled:
CRM
EMAIL
AUTOMATION
PROJECTS
BOOKING
FILES

Use these as generic illustrative categories, not as proof of a real technology stack.

At first, the cards look organized.

Then disconnected arrows and manual handoffs appear.

The number of cards increases, while the visual workflow becomes more confusing.

Create a highlighted paper headline:

"MORE TOOLS ≠ BETTER SYSTEMS"

Use a handmade marker underline.

Optionally show the narrator briefly while she discusses her experience.

Sound:
Soft paper layering, pencil strokes and UI clicks.

## SCENE 3 — TIME AND MOTHERHOOD
00:21.540–00:33.960

Narration discusses valuing time as a mom and not wanting to babysit software.

Visuals:

The software-card collage shifts into a paper calendar and business task list.

Introduce a small square narrator frame for the personal statement.

Add warm paper illustrations of:
- A calendar
- A clock
- Business reminders
- A small toy silhouette

Avoid fake family footage or artificially generated family photographs.

On "babysitting a software," animate a small paper application card sitting in a cartoon-like paper stroller or needing an exaggerated attention reminder.

Keep this tasteful and brief.

Sound:
Warm, subtle comedic accent.

Music:
Soften the instrumental mood.

## SCENE 4 — INTRODUCE KEEP, FIX, CANCEL
00:33.960–00:36.880

Narration:

"So before 2027, here's what I'd recommend."

Visuals:

Three large paper folders slide into the center.

They are labeled:

KEEP
FIX
CANCEL

Show an animated handwritten date:

"BEFORE 2027"

Let the three folders settle.

Use a clear visual transition into the first recommendation.

## SCENE 5 — KEEP
00:37.020–00:46.400

Narration:

"Keep the tools and processes that actually work. If they're reliable and making your life easier there's no need to change them."

Visuals:

Open the KEEP folder.

A selection of software cards receives small approval stamps.

Animate a card labeled "RELIABLE" being moved into the folder.

Use a handwritten green checkmark.

Display the important phrase:

"IF IT WORKS, KEEP IT."

Use a soft highlight stroke.

The movement should feel reassuring, orderly and calm.

No exaggerated celebratory effects.

## SCENE 6 — FIX
00:47.380–00:58.500

Narration discusses copying information between applications and connecting systems or simplifying processes.

Visuals:

Open the FIX folder.

Show two separated paper software cards:

CONTACT FORM
CRM

An information card must be manually carried between them.

Repeat the transfer to illustrate unnecessary work.

Then use a hand-drawn line to connect the applications.

Animate the information card traveling automatically along the line.

Create a before-and-after comparison:

BEFORE: MANUAL COPY
AFTER: CONNECTED FLOW

Use actual narration timing.

The visual must demonstrate the operational improvement clearly.

Make this one of the strongest animations.

Use paper movement, trimmed hand-drawn paths, subtle shadows and tactile sound effects.

Avoid suggesting that all apps integrate automatically without proper configuration.

## SCENE 7 — CANCEL
00:59.360–01:10.780

Narration discusses removing tools that are no longer needed and reviewing forgotten subscriptions or duplicate applications.

Visuals:

Open the CANCEL folder.

Several paper subscription receipts tumble onto the desk.

Two application cards show overlapping functions.

A hand-drawn circle highlights the duplication.

Stamp the top card:

"REVIEW"

Then introduce:

"STILL USING THIS?"

An unnecessary card may slide toward an archive or cancellation folder, but do not depict immediate irreversible deletion.

The focus is thoughtful evaluation before removing tools.

Sound:
- Paper shuffle
- Receipt drop
- Rubber stamp

## SCENE 8 — CHECK BEFORE CANCELLING
01:10.980–01:15.080

Narration:

"Just check your data and integrations before canceling anything."

Visuals:

Pause the cancellation movement.

Reveal a paper checklist:

DATA BACKED UP?
INTEGRATIONS CHECKED?
WORKFLOWS REVIEWED?

Animate an editorial warning annotation:

"CHECK FIRST"

The checkboxes should appear as review steps, not automatically completed tasks.

Do not visually imply that backing up data has already happened.

## SCENE 9 — FINAL TAKEAWAY
01:15.820–01:21.900

Narration:

"...your systems should be working for you not the other way around."

Visuals:

Return to the complete paper desk.

The previously messy software stack is now organized into three folders.

Use a slow overhead camera pullback.

Reveal a large editorial statement:

"YOUR SYSTEMS SHOULD WORK FOR YOU."

Apply a bold, hand-drawn underline.

This is the most important final takeaway.

Music should resolve gently.

## SCENE 10 — OPEN-ENDED TEASER
01:22.520–01:27.820

Narration:

"And if you're wondering why I'm saying all this, well it's because..."

Visuals:

Reveal the narrator in a small square paper frame again.

The surrounding paper elements gradually move aside.

A fresh blank paper sheet enters.

Add an understated on-screen teaser:

"THERE'S A REASON..."

Let the unfinished narration remain intentionally unfinished.

Do not invent an additional spoken line.

Do not add a large promotional CTA that interrupts the tease.

End with a tasteful, brief visual hold if the footage supports it.

---

# 8. MUSIC DIRECTION

Create a timestamped audio cue sheet after inspecting the original video.

Suggested score:

Opening:
Curious, lightly playful instrumental.

Expertise:
Minimal documentary rhythm, light percussion or clean electronic textures.

Motherhood:
Warmer, softer musical texture.

Keep:
Calm, reassuring instrumental.

Fix:
Slightly more rhythmic, with a subtle sense of discovery.

Cancel:
Lightly playful but controlled.

Final takeaway:
Warm and confident musical resolution.

Teaser:
Brief restrained suspense or curiosity.

Do not force music changes at fixed intervals.

Use only licensed or explicitly authorized audio assets.

Do not invent actual available tracks or their licenses.

If music files are unavailable, provide the cue sheet and prepare the project to accept replacement tracks later.

---

# 9. SOUND EFFECT DESIGN

Create or use subtle, properly licensed sounds for:

- Paper drops
- Paper movement
- Page flips
- Pen strokes
- Highlighter swipes
- Rubber stamps
- Scissors
- Typewriter accents
- Soft mouse clicks
- Folder opening
- Card stacking
- Gentle UI confirmations

Synchronize each effect to a visible action.

Avoid exaggerated swooshes and repetitive sound effects.

Do not put an effect on every animated object.

Prioritize clean dialogue.

---

# 10. REMOTION ENGINEERING

Use current supported Remotion APIs.

Inspect the project and available dependencies before implementing.

For source video, prefer the currently recommended Remotion media components when compatible with the installed version.

Use `@remotion/captions` and its `parseSrt()` functionality for the subtitle file.

Keep SRT parsing separate from the animation logic.

Create reusable components:

- PaperBackground
- PaperTexture
- TornPaper
- PaperCard
- PaperFolder
- PaperStamp
- PaperHighlight
- HandDrawnArrow
- PaperCutout
- PaperParallax
- StopMotionTransform
- SquareNarrator
- WorkflowDiagram
- SoftwareCard
- PaperChecklist
- EditorialHeadline
- CaptionOverlay
- MusicTrack
- SoundEffectCue

Use TypeScript.

Provide configurable brand color tokens.

Provide configurable shadow settings.

Use SVG masks, CSS clipping, or prepared transparent image assets for torn-paper edges.

Use seeded randomness for irregular borders and subtle collage offsets.

Use deterministic frame-based animation.

Do not introduce unstable external dependencies without need.

Synchronize all graphics to the parsed subtitle timing and verified source footage.

For edited source footage, maintain accurate source-to-output timestamp mapping.

Do not assume each subtitle cue identifies an exact individual word onset.

Use word-level alignment only when reliable word timing is actually available.

---

# 11. QUALITY REQUIREMENTS

Render and inspect preview frames from every major scene.

Review:
- Paper texture realism
- Layer shadows
- Typography
- Narrator framing
- Caption accuracy
- Scene transitions
- Paper movement
- Timing
- Voice clarity
- Sound effects
- Music ducking
- Overall composition
- Platform safe areas

Do not cover important information with the narrator window.

Do not crop the speaker's face awkwardly.

Do not make the entire video look like static PowerPoint slides with paper backgrounds.

The paper elements must have believable movement, depth and physical behavior.

Avoid excessive clutter.

Every shot should have one clear visual focal point.

Use full-screen paper animation as the primary style.

Treat the square narrator window as an occasional accent.

---

# 12. OUTPUTS

Deliver:

1. Finished 9:16 MP4
2. Editable Remotion project
3. Corrected SRT file
4. Timestamped scene plan
5. Music and SFX cue sheet
6. Preview frames
7. Quality-control report

Preserve the original source video and SRT.

Do not claim final files exist unless they have been rendered and verified.

---

# FINAL DIRECTIVE

This video should feel like a premium, animated editorial documentary made with physical paper materials.

Imagine an overhead camera filming a beautifully designed editorial desk while papers, printed screenshots, folders, handwritten annotations, software cards, and diagrams come alive.

The original presenter narrates the story. Her face appears selectively as a small square moving-image portrait.

The story unfolds visually rather than depending on talking-head footage.

Use the recurring software-card stack to connect every scene, from the opening problem to the final KEEP, FIX, CANCEL transformation.

Preserve the narrator's humor, personality, and professional credibility.

Make the animation genuinely beautiful, purposeful, tactile, and memorable.

Implement this in Remotion, preview the actual results, fix visual problems, and export the finished production.