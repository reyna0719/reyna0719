# Systems & Snuggle — KEEP, FIX, CANCEL

Play the finished video in `deliverables/systems-snuggle-keep-fix-cancel.mp4`.
The complete editable Remotion project is in `edit/`; its README explains setup,
rendering, components, source timing, paper motion and audio assets.

The delivery folder also includes the corrected SRT, timestamped scene plan,
animation timeline, actual sound-effects cues, optional music plan, brand/source
notes, preview images and final quality-control report.

The project bundles all local assets required to reproduce this edit, including
the original voice and a 30fps square narrator derivative. The untouched full-frame
source is retained separately in the workspace and is the supplied Google Drive
video `160StxNq0y1NYIrN3of-CHM4Tag4XB1I8`. Source hashes are included in reports/.
No licensed music was supplied; the music track is disabled.
