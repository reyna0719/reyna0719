# Before 2027: KEEP, FIX or CANCEL your business tools

Systems & Snuggle paper-cut documentary explainer.
**1080×1920, 30 fps, 2,635 frames, 87.833 seconds.**

## Preview and render

Use Node 24 or another version supported by package.json.

```sh
cd edit
npm ci
npm run preview
npm run typecheck
npm run render
```

The tested cloud command uses `/usr/bin/chromium`, concurrency 2 and CRF 19.
On another OS, remove `--browser-executable=/usr/bin/chromium` and let Remotion
manage its supported browser. In the managed cloud workspace, set
`npm_config_cache=/workspace/.npm-cache` if the home npm cache is unwritable.
The prepared installation reuses the existing pinned Remotion 4.0.538 runtime;
node_modules is excluded from the source archive. `npm ci` restores dependencies.

## Production structure

- `src/Film.tsx`: authored scene sequences, shared source clock, narrator windows,
  dialogue and optional music/effects. Original narration is never cut or retimed.
- `src/components/Paper.tsx`: seeded materials/edges, paper motion, highlights,
  strokes, stamps, cutouts, shadows, parallax, typography and checklist primitives.
- `src/components/Desk.tsx`: recurring software-card identity, state transitions,
  and three independently layered folder backs/fronts.
- `src/components/SquareNarrator.tsx`: selective square portrait. Video stays
  30fps; it is muted to prevent duplicate dialogue.
- `src/components/Captions.tsx`: official Caption JSON displayed in a reserved
  two-line strip, with selective word emphasis.
- `src/components/Audio.tsx`: original foley stem and optional music envelope.
- `src/scenes/`: ten individually authored paper story scenes.
- `src/theme.ts`: verified brand tokens, a labeled semantic check color and
  configurable shadow presets.
- `src/data/timeline.json`: source/edit mapping, narration references and treatments.
- `src/data/captions.json`: parsed SRT with source-relative timestamps.
- `public/sound-cues.json`: actual, source-relative original sound cues.

The main composition is `KeepFixCancel`. Standalone visual studies for KEEP,
FIX and CANCEL are registered in the `Paper-studies` Studio folder. They use the
same source clock and illustration components as the final film.

## Physical animation

The same six software cards begin scattered and end organized in KEEP, FIX and
CANCEL folders. Changes are tied to the narration. The paper/card/folder moves
use selected 12-update-per-second timing, seeded edges and restrained settling.
Camera movement, marker paths, major text and narrator playback remain smooth
at 30fps. There are no CSS animations, browser timers or unseeded randomness.

`PaperMotion` exposes direction, delay/start, duration, smooth/stepped mode,
rotation, scale, intensity, lift, shadow and easing. `TornPaper` exposes texture,
edge seed, roughness and shadow. Materials are local PNGs, not external resources.
The camera pullback and mild paper-layer parallax provide restrained depth.

## Source and synchronization

The unmodified original video and SRT are retained in the workspace's `source/`
folder. The full recording is used, with no head/tail cuts, added dialogue or
speed changes. The unfinished final sentence remains unfinished.

The editable project bundles `public/narrator-square.mp4`: a 480×480, 30fps crop
from the original 1080×1920 footage, with no audio. It is larger than the maximum
300px display window. The crop is x=0,y=40,w=1080,h=1080 before scaling; it was
reviewed in the actual scene frames to retain natural facial expressions.
This derivative lets the complete project remain portable without bundling the
159MB full-frame original. The original is preserved separately and the Drive
source reference and hashes are documented in the delivery reports.

`public/dialogue.wav` is the original source audio normalized in two passes,
without pitch/timing changes. It shares source t=0 with the narrator proxy and
captions. Hiding the portrait never stops or duplicates the voice.

If adding future cuts, update the shared source/edit mapping and move the
synchronized group. Do not trim only video or only audio. Scene offsets are
centralized with each authored sequence and SourceOffset provider.

## Captions

`scripts/prepare-captions.mjs` imports the original SRT through the official
`parseSrt()` and exports the corrected SRT through `serializeSrt()`. It validates
positive durations, chronological order and at most two lines. Only punctuation
and sentence casing are corrected. Recorded wording such as “babysitting a
software”, “apps that's doing” and the unfinished ending is preserved.

Local recognition cross-checks the supplied transcript and helps position the
2027 and connected-flow graphics. Subtitle cues are not assumed to identify
exact individual word onsets. Original SRT times remain the caption basis.

## Audio assets and regeneration

There is no supplied licensed music, so `musicFile` defaults to an empty string.
The final mix contains the narrator plus 29 original procedural foley cues, with
no external sampled recordings. A future rights-cleared track can be placed in
public/ and selected in composition props; MusicTrack adds fades and narrative
volume dips. A new mix check is required after adding it.

Normal editing/rendering requires only Node and the bundled local assets.
Optional regeneration scripts need Python with NumPy/Pillow for textures and
foley. Neither Python nor speech-recognition models are required to render.

## Editorial safeguards

The software categories and contact records are illustrative, not a verified
client stack. example.com addresses are fictional. The connected flow assumes
proper configuration/testing. The CANCEL bucket contains review candidates;
no software account is cancelled, data deleted or backup claimed. The caution
checklist stays unchecked. No financial savings, statistics, results, testimonials
or licenses are fabricated. The closing phrase is not continued with new speech.

The project does not copy Vox marks, exact branding, footage or specific sequences.
Font licenses are bundled in public/fonts/licenses. See the adjacent delivery
reports for brand evidence, timelines, source hashes and final QA measurements.
