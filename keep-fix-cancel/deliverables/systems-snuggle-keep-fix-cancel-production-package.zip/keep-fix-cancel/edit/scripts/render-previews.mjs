import path from 'node:path';
import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill} from '@remotion/renderer';
const serveUrl=await bundle({entryPoint:path.resolve('src/index.ts'),rspack:true});const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try{
 const composition=await selectComposition({serveUrl,id:'KeepFixCancel',puppeteerInstance:browser});
 const shots=[['opening',5.4],['boss-question',9.0],['more-tools',19.7],['motherhood',25.5],['babysitting-software',31.4],['three-folders',35.5],['keep',41.7],['fix-manual',53.45],['fix-connected',57.45],['cancel-review',70.0],['check-first',73.3],['takeaway',80.2],['teaser',86.8]];
 for(let i=0;i<shots.length;i+=2)await Promise.all(shots.slice(i,i+2).map(async([name,t])=>{await renderStill({serveUrl,composition,frame:Math.round(t*30),output:`../deliverables/previews/${name}.png`,puppeteerInstance:browser,logLevel:'error'});console.log(`Rendered ${name} at ${t}s`);}));
}finally{await browser.close({silent:true});}
