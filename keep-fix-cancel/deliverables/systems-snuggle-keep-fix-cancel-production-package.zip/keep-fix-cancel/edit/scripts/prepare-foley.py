from pathlib import Path
import numpy as np,wave,json,csv
root=Path(__file__).resolve().parents[2];pub=root/'edit/public';out=root/'deliverables'
cues=[(.45,'drop','Subscription invoice lands'),(1.1,'paper','Software stack builds'),(1.9,'drop','Second paper layer'),(3.7,'typing','Repeated manual work'),(8.3,'click','The boss label flips'),(11.4,'paper','Software cards organize'),(18,'marker','More tools headline emphasis'),(22,'paper','Calendar and personal moment'),(30.66,'click','Software babysitting metaphor'),(33.18,'marker','Handwritten 2027'),(34.1,'folder','First folder settles'),(34.45,'folder','Folder group settles'),(37.15,'folder','KEEP opens'),(40.8,'stamp','Reliable stamp'),(43.8,'marker','KEEP checkmark'),(47.5,'folder','FIX opens'),(51.48,'typing','First manual copy'),(53,'typing','Repeated manual copy'),(56.08,'marker','Connect the applications'),(57.2,'click','Connected record arrives'),(59.6,'folder','CANCEL review folder'),(63.85,'drop','Forgotten subscription receipt'),(66.3,'paper','Compare overlapping functions'),(68.1,'marker','Circle duplicated functions'),(69.8,'stamp','REVIEW stamp'),(71.1,'paper','Pause and reveal review checklist'),(75.82,'folder','Organized stack pullback'),(79.2,'marker','Final takeaway underline'),(82.52,'paper','Fresh teaser sheet')]
cues.sort(key=lambda c:c[0]);sr=48000;length=2635*1600;audio=np.zeros((length,2),np.float64)
for at,kind,note in cues:
 rng=np.random.default_rng(round(at*100));duration={'drop':.18,'paper':.23,'typing':.26,'click':.05,'marker':.28,'folder':.24,'stamp':.14}[kind];t=np.arange(round(duration*sr))/sr;noise=rng.normal(0,1,len(t));smoothed=np.convolve(noise,np.ones(7)/7,mode='same');envelope=np.sin(np.pi*t/duration)**1.5
 if kind in ['paper','folder','marker']:x=.018*smoothed*envelope+(.006*np.sin(2*np.pi*180*t)*envelope if kind=='folder'else 0)
 elif kind in ['drop','stamp']:x=.035*np.sin(2*np.pi*(120 if kind=='drop'else 170)*t)*np.exp(-t*35)+.008*noise*np.exp(-t*70)
 elif kind=='click':x=.025*np.sin(2*np.pi*1350*t)*np.exp(-t*130)+.008*noise*np.exp(-t*190)
 else:
  x=np.zeros(len(t))
  for onset in [0,.075,.161]:
   q=t-onset;x+=np.where(q>=0,.022*np.sin(2*np.pi*1500*q)*np.exp(-np.maximum(q,0)*140),0)
 x*=np.minimum(t/.004,1)*np.minimum((duration-t)/.008,1);start=round(at*sr);pan=.08 if round(at)%2 else -.08
 audio[start:start+len(x),0]+=x*(1-pan);audio[start:start+len(x),1]+=x*(1+pan)
with wave.open(str(pub/'foley.wav'),'wb')as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes((audio*32767).astype('<i2').tobytes())
(pub/'sound-cues.json').write_text(json.dumps([dict(sourceSeconds=a,editedSeconds=a,type=b,description=c,rights='Original procedural foley; no third-party samples')for a,b,c in cues],indent=2)+'\n')
with (out/'sound-effects-cue-sheet.csv').open('w')as f:
 w=csv.writer(f);w.writerow(['source_seconds','edited_seconds','cue','description','rights']);w.writerows((a,a,b,c,'Original procedural foley')for a,b,c in cues)
print('Prepared',len(cues),'original foley cues; no music inserted.')
