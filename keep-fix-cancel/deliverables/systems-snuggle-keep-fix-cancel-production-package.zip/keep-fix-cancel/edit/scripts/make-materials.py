from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np
root=Path(__file__).resolve().parents[1]/'public/materials';root.mkdir(parents=True,exist_ok=True)
for name,color,seed in [('desk',(247,238,232),170),('ivory',(255,253,251),212),('kraft',(231,216,208),97),('rose',(201,143,123),56),('dark',(71,57,52),11)]:
 rng=np.random.default_rng(seed);n=640
 grain=rng.normal(0,1.5,(n,n,1));base=np.array(color)[None,None,:]+grain
 # Low-frequency pulp variation plus scattered fine physical fibres.
 coarse=Image.fromarray(np.clip(rng.normal(128,20,(40,40)),0,255).astype('uint8')).resize((n,n),Image.Resampling.BICUBIC)
 base+=(np.asarray(coarse)[:,:,None].astype(float)-128)*.065
 im=Image.fromarray(np.clip(base,0,255).astype('uint8'));d=ImageDraw.Draw(im,'RGBA')
 for i in range(2500):
  x,y=rng.integers(0,n,2);dx,dy=rng.integers(-7,8,2);d.line((int(x),int(y),int(x+dx),int(y+dy)),fill=(71,57,52,int(rng.integers(5,17))),width=1)
 for i in range(180):
  x,y=rng.integers(0,n,2);d.ellipse((int(x),int(y),int(x+2),int(y+1)),fill=(255,253,251,30))
 im.save(root/(name+'.png'))
# Reusable printed halftone, alpha-only so its color remains subordinate.
im=Image.new('RGBA',(300,300),(0,0,0,0));d=ImageDraw.Draw(im)
for y in range(0,300,13):
 for x in range(0,300,13):d.ellipse((x,y,x+2,y+2),fill=(71,57,52,28))
im.save(root/'halftone.png')
print('Generated six local, seeded paper materials.')
