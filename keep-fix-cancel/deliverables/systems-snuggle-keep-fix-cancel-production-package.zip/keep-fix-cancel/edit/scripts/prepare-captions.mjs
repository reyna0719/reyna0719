import fs from 'node:fs';
import {parseSrt,serializeSrt} from '@remotion/captions';
const raw=fs.readFileSync('../source/Edit Phase 1.srt','utf8');
const {captions}=parseSrt({input:raw});
const punctuation={2:'work, right?',4:'you theirs?',7:"doesn't always mean your business is running better.",8:"And now that I'm a mom, I value",9:'my time even more. And I love technology,',11:'free time babysitting a software. So before 2027,',12:"here’s what I’d recommend.",17:"If you're still copying information between different applications,",19:'simplify the process.',22:"Those forgotten subscriptions or apps that's doing practically",23:'the same thing, review them.',25:'anything.',26:'So because at the end of the day,',27:'your systems should be working for you, not',29:"And if you're wondering why I'm saying all",30:"this, well it's because..."};
const wrap=(s,max=38)=>{const lines=[];let l='';for(const w of s.split(/\s+/)){if(l&&l.length+w.length+1>max){lines.push(l);l=w;}else l+=(l?' ':'')+w;}if(l)lines.push(l);return lines;};
for(let i=0;i<captions.length;i++){if(i in punctuation)captions[i].text=punctuation[i];captions[i].text=wrap(captions[i].text).join('\n');if(captions[i].text.split('\n').length>2)throw Error('Caption needs a reliable phrase split: '+i);}
for(let i=0;i<captions.length;i++){if(captions[i].endMs<=captions[i].startMs)throw Error('Invalid cue');if(i&&captions[i].startMs<captions[i-1].endMs)throw Error('Overlap');}
fs.writeFileSync('src/data/captions.json',JSON.stringify(captions,null,2)+'\n');
fs.writeFileSync('../deliverables/systems-snuggle-keep-fix-cancel-corrected.srt',serializeSrt({lines:captions.map(c=>[c])}));
console.log('Parsed',captions.length,'caption pages using official Remotion captions APIs.');
