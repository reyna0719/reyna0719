import {AbsoluteFill,Composition,Folder,Sequence,useVideoConfig} from 'remotion';
import {KeepFixCancel,PaperStory} from './Film';
import {T,PaperBackground} from './components/Paper';
const KeepStudy=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{fontFamily:T.body,color:T.ink}}><PaperBackground/><Sequence from={-Math.round(37.02*fps)} premountFor={fps}><PaperStory/></Sequence></AbsoluteFill>;};
const FixStudy=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{fontFamily:T.body,color:T.ink}}><PaperBackground/><Sequence from={-Math.round(47.38*fps)} premountFor={fps}><PaperStory/></Sequence></AbsoluteFill>;};
const CancelStudy=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{fontFamily:T.body,color:T.ink}}><PaperBackground/><Sequence from={-Math.round(59.36*fps)} premountFor={fps}><PaperStory/></Sequence></AbsoluteFill>;};
export const RemotionRoot=()=> <>
 <Composition id="KeepFixCancel"component={KeepFixCancel}width={1080}height={1920}fps={30}durationInFrames={2635}defaultProps={{musicFile:'',musicGain:.055,effectsGain:1}}/>
 <Folder name="Paper-studies"><Composition id="KeepFolder"component={KeepStudy}width={1080}height={1920}fps={30}durationInFrames={310}/><Composition id="FixWorkflow"component={FixStudy}width={1080}height={1920}fps={30}durationInFrames={359}/><Composition id="CancelReview"component={CancelStudy}width={1080}height={1920}fps={30}durationInFrames={348}/></Folder>
</>;
