import React from 'react';
import {AbsoluteFill,Sequence,staticFile,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {T,PaperBackground,PaperParallax,SourceOffset,clock,p,lerp} from './components/Paper';
import {SoftwareDeck,PaperFolder} from './components/Desk';
import {SquareNarrator} from './components/SquareNarrator';
import {CaptionOverlay} from './components/Captions';
import {MusicTrack,SoundEffectCue} from './components/Audio';
import captions from './data/captions.json';
import {Opening} from './scenes/Opening';
import {Expertise} from './scenes/Expertise';
import {Personal} from './scenes/Personal';
import {Introduction} from './scenes/Introduction';
import {Keep} from './scenes/Keep';
import {Fix} from './scenes/Fix';
import {Cancel} from './scenes/Cancel';
import {Check} from './scenes/Check';
import {Final} from './scenes/Final';
import {Teaser} from './scenes/Teaser';
import './fonts';import './style.css';
export type FilmProps={musicFile:string;musicGain:number;effectsGain:number};
export const PaperStory:React.FC=()=>{
 const t=clock();const {fps}=useVideoConfig();let zoom=t<11.26?lerp(1.018,1,p(t,0,10)):1;if(t>=75.82)zoom=lerp(1.03,.94,p(t,75.82,6));if(t>=82.52)zoom=lerp(.94,1,p(t,82.52,.65));
 return <div style={{position:'absolute',inset:0,scale:zoom,transformOrigin:'50% 54%'}}>
  <PaperFolder index={0}/><PaperFolder index={1}/><PaperFolder index={2}/>
  <SoftwareDeck/>
  <Sequence name="Software subscriptions and the boss question"durationInFrames={Math.round(11.26*fps)}premountFor={fps}><Opening/></Sequence>
  <Sequence name="More tools do not equal better systems"from={Math.round(11.26*fps)}durationInFrames={Math.round(21.54*fps)-Math.round(11.26*fps)}premountFor={fps}><SourceOffset.Provider value={Math.round(11.26*fps)/fps}><Expertise/></SourceOffset.Provider></Sequence>
  <Sequence name="Time, motherhood and babysitting software"from={Math.round(21.54*fps)}durationInFrames={Math.round(32.18*fps)-Math.round(21.54*fps)}premountFor={fps}><SourceOffset.Provider value={Math.round(21.54*fps)/fps}><Personal/></SourceOffset.Provider></Sequence>
  <Sequence name="Before 2027: three folders"from={Math.round(32.18*fps)}durationInFrames={Math.round(37.02*fps)-Math.round(32.18*fps)}premountFor={fps}><SourceOffset.Provider value={Math.round(32.18*fps)/fps}><Introduction/></SourceOffset.Provider></Sequence>
  <Sequence name="KEEP reliable tools"from={Math.round(37.02*fps)}durationInFrames={Math.round(47.38*fps)-Math.round(37.02*fps)}premountFor={fps}><SourceOffset.Provider value={Math.round(37.02*fps)/fps}><Keep/></SourceOffset.Provider></Sequence>
  <Sequence name="FIX the handoff: manual to connected flow"from={Math.round(47.38*fps)}durationInFrames={Math.round(59.36*fps)-Math.round(47.38*fps)}premountFor={fps}><SourceOffset.Provider value={Math.round(47.38*fps)/fps}><Fix/></SourceOffset.Provider></Sequence>
  <Sequence name="CANCEL only after thoughtful review"from={Math.round(59.36*fps)}durationInFrames={Math.round(70.98*fps)-Math.round(59.36*fps)}premountFor={fps}><SourceOffset.Provider value={Math.round(59.36*fps)/fps}><Cancel/></SourceOffset.Provider></Sequence>
  <Sequence name="Check data and integrations first"from={Math.round(70.98*fps)}durationInFrames={Math.round(75.82*fps)-Math.round(70.98*fps)}premountFor={fps}><SourceOffset.Provider value={Math.round(70.98*fps)/fps}><Check/></SourceOffset.Provider></Sequence>
  <Sequence name="An organized stack that works for you"from={Math.round(75.82*fps)}durationInFrames={Math.round(82.52*fps)-Math.round(75.82*fps)}premountFor={fps}><SourceOffset.Provider value={Math.round(75.82*fps)/fps}><Final/></SourceOffset.Provider></Sequence>
  <Sequence name="Original unfinished teaser"from={Math.round(82.52*fps)}durationInFrames={2635-Math.round(82.52*fps)}premountFor={fps}><SourceOffset.Provider value={Math.round(82.52*fps)/fps}><Teaser/></SourceOffset.Provider></Sequence>
  <PaperFolder index={0}front/><PaperFolder index={1}front/><PaperFolder index={2}front/>
 </div>;
};
export const KeepFixCancel:React.FC<FilmProps>=({musicFile,musicGain,effectsGain})=>{
 const {fps}=useVideoConfig();return <AbsoluteFill style={{fontFamily:T.body,color:T.ink,background:T.cream}}>
  <PaperBackground/>
  <Sequence name="Uncut original narration with synchronized visual story"durationInFrames={2635}premountFor={fps}>
   <Audio src={staticFile('dialogue.wav')}premountFor={fps}/><SoundEffectCue gain={effectsGain}/><MusicTrack file={musicFile}gain={musicGain}/>
   <PaperParallax depth={.8}style={{position:'absolute',inset:0}}><PaperStory/></PaperParallax>
   <div style={{position:'absolute',inset:0,zIndex:80,pointerEvents:'none'}}>
    <SquareNarrator x={740}y={205}size={250}start={6.98}end={10.7}seed={100}/>
    <SquareNarrator x={745}y={205}size={250}start={11.26}end={15.3}seed={120}rotation={1.4}/>
    <SquareNarrator x={720}y={650}size={280}start={22.15}end={27.8}seed={140}/>
    <SquareNarrator x={740}y={470}size={250}start={29.9}end={31.9}seed={160}rotation={1.2}/>
    <SquareNarrator x={385}y={505}size={300}start={82.52}end={87.83}seed={180}/>
   </div>
   <CaptionOverlay captions={captions}/>
  </Sequence>
  <div style={{position:'absolute',left:64,top:80,zIndex:100,fontFamily:T.wordmark,fontSize:28,color:T.ink}}>Systems & Snuggle <span style={{fontFamily:T.body,fontSize:15,fontWeight:700,letterSpacing:3,marginLeft:20}}>THE TOOL REVIEW</span></div>
 </AbsoluteFill>;
};
