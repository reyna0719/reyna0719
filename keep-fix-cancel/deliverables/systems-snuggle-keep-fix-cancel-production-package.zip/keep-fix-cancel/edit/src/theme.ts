// Verified from Systems & Snuggle's live homepage CSS on 2026-10-29.
export const theme={
 cream:'#F7EEE8',paper:'#FFFDFB',rose:'#C98F7B',roseDark:'#AD705E',ink:'#473934',muted:'#83736C',line:'#E7D8D0',
 headline:'Montserrat',body:'Montserrat',wordmark:'Tenor Sans',
 // Functional annotation color requested for the KEEP check; not an official brand color.
 semanticCheck:'#596951',
 shadows:{rest:'5px 8px 6px rgba(71,57,52,.17)',lift:'10px 22px 22px rgba(71,57,52,.22)',thin:'2px 4px 3px rgba(71,57,52,.13)'},
}as const;
