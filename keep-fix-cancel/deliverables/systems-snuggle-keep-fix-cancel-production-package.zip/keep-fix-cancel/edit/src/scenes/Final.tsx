import React from 'react';
import {T,PaperMotion,EditorialHeadline,Label,PaperHighlight,Annotation,TornPaper,PaperStamp,clock,p} from '../components/Paper';
export const Final:React.FC=()=>{
 const t=clock();return <>
  <PaperMotion at={75.82}stepped={false}style={{position:'absolute',left:64,top:205}}><Label>THE LARGER POINT</Label><div style={{position:'absolute',left:-5,top:270}}><PaperHighlight at={79.0}width={760}thickness={80}/></div><EditorialHeadline size={95}style={{marginTop:28,position:'relative',opacity:p(t,77.75,.4)}}>YOUR SYSTEMS<br/>SHOULD WORK<br/>FOR YOU.</EditorialHeadline>{t<77.75&&<EditorialHeadline size={77}style={{marginTop:45}}>AT THE END<br/>OF THE DAY...</EditorialHeadline>}</PaperMotion>
  <div style={{position:'absolute',left:65,top:570}}><Annotation at={79.2}width={850}height={60}/></div>
  <PaperMotion at={76.1} rotation={-3} style={{position:'absolute',left:90,top:665,width:500,height:300}}><TornPaper seed={650}kind="ivory"style={{width:'100%',height:'100%'}}contentStyle={{padding:32}}><Label color={T.ink}>SOFTWARE REVIEW</Label><div style={{height:2,background:T.ink,marginTop:18}}/><div style={{fontSize:28,fontWeight:600,lineHeight:1.6,marginTop:20}}>Does it work?<br/>Can it work better?<br/>Do you still need it?</div></TornPaper></PaperMotion>
  <div style={{position:'absolute',left:650,top:725}}><PaperStamp text="YOUR CALL"at={78.4}rotation={6}style={{fontSize:32}}/><div style={{marginTop:30}}><Annotation type="arrow"at={79.3}width={220}height={160}/></div></div>
 </>;
};
