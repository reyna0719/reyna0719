import React from 'react';
import {TornPaper,PaperMotion,EditorialHeadline,Label,Tape,Annotation} from '../components/Paper';
export const Teaser:React.FC=()=> <>
 <PaperMotion at={82.52}duration={.7}stepped={false}direction="left"style={{position:'absolute',left:90,top:310,width:900,height:1100,zIndex:50}}><TornPaper seed={711}rough={1.4}style={{width:'100%',height:'100%'}}contentStyle={{padding:55}}><Label>ONE MORE THOUGHT</Label><div style={{position:'absolute',left:65,top:620}}><EditorialHeadline size={91}>THERE’S<br/>A REASON...</EditorialHeadline><Annotation at={85.8}width={730}height={75}/></div></TornPaper><Tape seed={335}style={{position:'absolute',left:150,top:-15,rotate:'-11deg'}}/><Tape seed={336}style={{position:'absolute',right:130,top:-15,rotate:'7deg'}}/></PaperMotion>
</>;
