import React from 'react';
import {T,TornPaper,PaperMotion,EditorialHeadline,Label,PaperStamp,Annotation,clock,p} from '../components/Paper';
export const Cancel:React.FC=()=>{
 const t=clock();return <>
  <PaperMotion at={59.36} stepped={false} style={{position:'absolute',left:64,top:205}}><Label>03 / REVIEW WHAT YOU NO LONGER NEED</Label><EditorialHeadline size={96} style={{marginTop:28}}>STILL<br/>USING THIS?</EditorialHeadline></PaperMotion>
  {[0,1,2].map(i=><PaperMotion key={i} at={63.78+i*.22} rotation={[-9,8,-3][i]}direction="up" style={{position:'absolute',left:95+i*190,top:560+i*35,zIndex:1,width:360,height:460}}><TornPaper seed={310+i*17} rough={2.2}style={{width:'100%',height:'100%'}}contentStyle={{padding:28}}><Label color={T.ink}>SUBSCRIPTION</Label><div style={{height:2,background:T.ink,marginTop:20}}/><div style={{fontSize:23,marginTop:25,lineHeight:1.6}}>Recurring renewal<br/>Last used: review<br/>Still needed?</div><div style={{marginTop:25,borderTop:`2px dashed ${T.line}`}}/><div style={{fontSize:17,color:T.muted,marginTop:20}}>SUBSCRIPTION REVIEW<br/>STILL NEEDED?</div></TornPaper></PaperMotion>)}
  <PaperMotion at={66.25}rotation={-2}style={{position:'absolute',left:160,top:710,zIndex:24}}><TornPaper seed={321}kind="ivory"style={{width:350,height:285}}contentStyle={{padding:28}}><Label color={T.ink}>APP A</Label><EditorialHeadline size={39}style={{marginTop:22,letterSpacing:-1}}>SENDS EMAIL</EditorialHeadline><div style={{fontSize:23,marginTop:25}}>Same job?</div></TornPaper></PaperMotion>
  <PaperMotion at={67.1}rotation={3}style={{position:'absolute',left:570,top:740,zIndex:25}}><TornPaper seed={369}style={{width:350,height:285}}contentStyle={{padding:28}}><Label color={T.ink}>APP B</Label><EditorialHeadline size={39}style={{marginTop:22,letterSpacing:-1}}>SENDS EMAIL</EditorialHeadline><div style={{fontSize:23,marginTop:25}}>Same job?</div></TornPaper></PaperMotion>
  <div style={{position:'absolute',left:155,top:785,zIndex:28}}><Annotation type="circle"at={68.1}width={780}height={150}/></div>
  <div style={{position:'absolute',left:405,top:1025,zIndex:29}}><PaperStamp text="REVIEW"at={69.8}rotation={-7}/></div>
  <div style={{position:'absolute',left:80,top:505,opacity:p(t,63.78),fontSize:22,fontWeight:600,color:T.muted}}>Example overlap. Check your own stack.</div>
 </>;
};
