import React from 'react';
import {T,PaperMotion,EditorialHeadline,Label,PaperLabel,Annotation,clock,p,lerp} from '../components/Paper';
import {SoftwareCard} from '../components/Desk';
const cubic=(a:number,b:number,c:number,d:number,q:number)=>(1-q)**3*a+3*(1-q)**2*q*b+3*(1-q)*q*q*c+q*q*q*d;
export const WorkflowDiagram:React.FC=()=>{
 const t=clock();const connected=t>=55.86;let packet=0,visible=false;
 if(t>=51.48&&t<52.35){packet=p(t,51.48,.7);visible=true;}if(t>=53&&t<53.9){packet=p(t,53,.7);visible=true;}
 const filing=p(t,58.65,.55);const auto=p(t,56.65,.75);const x=connected?cubic(475,515,545,585,auto):lerp(420,630,packet);const y=connected?cubic(800,765,835,800,auto):800;
 return <>
  <PaperMotion at={50.44} rotation={-1.2} style={{position:'absolute',left:lerp(75,220,filing),top:lerp(640,1280,filing),scale:lerp(1.34,.65,filing),transformOrigin:'top left',zIndex:20}}><SoftwareCard label="CONTACT FORM" kind="form" seed={188}><div style={{fontSize:21,fontWeight:700,marginTop:20}}>Alex Morgan</div><div style={{fontSize:18,marginTop:12}}>alex@example.com</div><div style={{marginTop:18,fontSize:16,fontWeight:800,color:T.roseDark}}>ONE INQUIRY</div></SoftwareCard></PaperMotion>
  <svg width={1080}height={1170}style={{position:'absolute',inset:0,zIndex:25,pointerEvents:'none',opacity:p(t,50.44)*(1-p(t,58.65,.3))}}><path d="M475 800C515 765 545 835 585 800" stroke={T.line}strokeWidth={4}fill="none"strokeDasharray={connected?'none':'7 9'}/><path d="M475 800C515 765 545 835 585 800" stroke={T.roseDark}strokeWidth={5}fill="none"pathLength={1}strokeDasharray={1}strokeDashoffset={1-p(t,56.08,.7)}/>{((!connected&&visible)||(connected&&auto>0&&auto<1))&&<g transform={`translate(${x},${y})`}><rect x={-25}y={-32}width={50}height={64}fill={T.paper}stroke={T.roseDark}strokeWidth={2}/><path d="M-14-16h28M-14-5h28M-14 6h20M-14 17h24" stroke={T.ink}strokeWidth={2}/>{!connected&&<path d="M14 21v35l8-10 8 14 7-5-9-14 13-2Z" fill={T.ink}/>}</g>}</svg>
  <div style={{position:'absolute',left:75,top:1050,zIndex:25}}><PaperLabel style={{fontSize:28}}>{connected?'AFTER: CONNECTED FLOW':'BEFORE: MANUAL COPY'}</PaperLabel>{connected&&<div style={{fontSize:24,fontWeight:600,color:T.muted,marginTop:16}}>After proper setup and testing.</div>}</div>
  <div style={{position:'absolute',left:80,top:990,zIndex:25}}><Annotation type="underline" at={56.35} width={900}height={45}/></div>
 </>;
};
export const Fix:React.FC=()=> <>
 <PaperMotion at={47.38} stepped={false} style={{position:'absolute',left:64,top:205}}><Label>02 / FIX WHAT CREATES EXTRA WORK</Label><EditorialHeadline size={99} style={{marginTop:28}}>CONNECT IT.<br/><span style={{color:T.roseDark}}>SIMPLIFY IT.</span></EditorialHeadline></PaperMotion>
 <div style={{position:'absolute',left:75,top:520,fontSize:28,fontWeight:600,color:T.muted}}>The tool may stay. The handoff can change.</div>
 <WorkflowDiagram/>
</>;
