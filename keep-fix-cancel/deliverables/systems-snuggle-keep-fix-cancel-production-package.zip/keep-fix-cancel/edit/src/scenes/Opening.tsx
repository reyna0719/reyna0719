import React from 'react';
import {T,TornPaper,PaperMotion,PaperLabel,EditorialHeadline,Label,Icon,Annotation,clock,p,lerp} from '../components/Paper';
export const Opening:React.FC=()=>{
 const t=clock();const flip=p(t,8.3,.4);return <>
  <PaperMotion at={.15} stepped={false} style={{position:'absolute',left:64,top:200,width:660}}><Label>THE SOFTWARE PROBLEM</Label><EditorialHeadline size={91} style={{marginTop:22}}>{t<3.35?<>PAYING FOR<br/>SOFTWARE.</>:<>WHO’S DOING<br/>THE WORK?</>}</EditorialHeadline>{t>=3.35&&<div style={{position:'absolute',left:0,top:215}}><Annotation at={3.5} width={650}/></div>}</PaperMotion>
  <PaperMotion at={.45} direction="up" rotation={-2.5} style={{position:'absolute',left:70,top:520,width:790,height:460}}><TornPaper seed={8} rough={1.5} style={{width:'100%',height:'100%'}} contentStyle={{padding:40}}><Label color={T.ink}>SOFTWARE SUBSCRIPTIONS</Label><div style={{height:2,background:T.ink,marginTop:22}}/><div style={{display:'flex',justifyContent:'space-between',fontSize:25,marginTop:30}}><span>Recurring tools</span><span>PAID</span></div><div style={{marginTop:35,borderBottom:`2px dashed ${T.line}`}}/><div style={{fontSize:20,color:T.muted,marginTop:30}}>THE SOFTWARE IS PAID.<br/>THE MANUAL WORK IS STILL YOURS.</div></TornPaper></PaperMotion>
  {t>2.7&&t<6.5&&<div style={{position:'absolute',left:lerp(310,735,((t-2.7)%1.3)/1.3),top:lerp(900,1100,((t-2.7)%1.3)/1.3),zIndex:30,rotate:'-8deg'}}><TornPaper seed={19} style={{width:90,height:110}} contentStyle={{padding:15}}><Icon kind="form" size={58}/></TornPaper><div style={{position:'absolute',left:60,top:75}}><Icon kind="cursor" size={48}/></div></div>}
  <PaperMotion at={6.98} style={{position:'absolute',left:510,top:1380,zIndex:32}}><PaperLabel style={{fontSize:34,scale:`${Math.max(.1,Math.abs(1-2*flip))} 1`}}>THE BOSS?</PaperLabel></PaperMotion>
  <div style={{position:'absolute',left:870,top:1280,zIndex:31,opacity:p(t,6.98),rotate:'4deg'}}><Icon kind={flip<.5?'person':'automation'} size={100}/></div>
  {t>7&&<div style={{position:'absolute',left:740,top:1370,zIndex:30,rotate:'-15deg'}}><Annotation type="arrow" at={7.3} width={160} height={80}/></div>}
 </>;
};
