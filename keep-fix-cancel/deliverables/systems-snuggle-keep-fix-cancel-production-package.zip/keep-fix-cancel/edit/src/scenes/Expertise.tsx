import React from 'react';
import {T,PaperMotion,EditorialHeadline,Label,PaperHighlight,Annotation,clock,p} from '../components/Paper';
import {SoftwareCard} from '../components/Desk';
export const Expertise:React.FC=()=>{
 const t=clock();return <>
  <PaperMotion at={11.26} stepped={false} style={{position:'absolute',left:64,top:205,width:655}}><Label>YEARS BEHIND THE BUSINESS BACKEND</Label><div style={{position:'absolute',left:-5,top:155,zIndex:0}}><PaperHighlight width={630} at={18} thickness={79}/></div><EditorialHeadline size={83} style={{marginTop:28,position:'relative'}}>MORE TOOLS<br/>≠ BETTER<br/>SYSTEMS.</EditorialHeadline></PaperMotion>
  <svg width={1080} height={1470} style={{position:'absolute',inset:0,zIndex:25,pointerEvents:'none',opacity:p(t,16)}}><path d="M410 720H565M760 850L410 1000M410 1000H565M760 1130L420 1280" stroke={T.roseDark} strokeWidth={3} strokeDasharray="7 10" fill="none"/><path d="m475 699 24 40m0-40-24 40M470 980l25 36m0-36-25 36" stroke={T.roseDark} strokeWidth={5}/></svg>
  <PaperMotion at={18.25} rotation={7} style={{position:'absolute',left:420,top:870,zIndex:6,opacity:.8}}><SoftwareCard label="ANOTHER APP" kind="automation" seed={162}/></PaperMotion>
  <PaperMotion at={19.1} rotation={-8} style={{position:'absolute',left:330,top:1150,zIndex:7,opacity:.6}}><SoftwareCard label="ONE MORE" kind="projects" seed={198}/></PaperMotion>
  <div style={{position:'absolute',left:360,top:1405,zIndex:30}}><Annotation at={19.2} width={580} height={45}/></div>
 </>;
};
