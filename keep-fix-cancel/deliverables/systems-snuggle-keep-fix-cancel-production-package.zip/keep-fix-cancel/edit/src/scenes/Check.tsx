import React from 'react';
import {T,TornPaper,PaperMotion,EditorialHeadline,Label,PaperChecklist,PaperLabel,Annotation} from '../components/Paper';
export const Check:React.FC=()=> <>
 <PaperMotion at={70.98}stepped={false}style={{position:'absolute',left:64,top:205,zIndex:55}}><Label>BEFORE YOU CANCEL ANYTHING</Label><EditorialHeadline size={103}style={{marginTop:28}}>CHECK<br/><span style={{color:T.roseDark}}>FIRST.</span></EditorialHeadline></PaperMotion>
 <PaperMotion at={71.1}rotation={-1}style={{position:'absolute',left:75,top:590,width:920,height:750,zIndex:54}}><TornPaper seed={490}rough={1.9}kind="ivory"style={{width:'100%',height:'100%'}}contentStyle={{padding:46}}><PaperLabel>PAUSE THE CANCELLATION</PaperLabel><PaperChecklist at={71.25}items={['DATA BACKED UP?','INTEGRATIONS CHECKED?','WORKFLOWS REVIEWED?']}style={{marginTop:42}}/><div style={{fontSize:24,color:T.muted,lineHeight:1.5,marginTop:45}}>Review these before making changes.<br/>Protect the data and processes you rely on.</div></TornPaper></PaperMotion>
 <div style={{position:'absolute',left:610,top:425,zIndex:57,rotate:'20deg'}}><Annotation type="arrow"at={71.4}width={290}height={110}/></div>
</>;
