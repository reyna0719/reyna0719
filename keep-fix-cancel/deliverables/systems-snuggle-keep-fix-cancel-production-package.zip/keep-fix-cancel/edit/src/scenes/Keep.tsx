import React from 'react';
import {T,PaperMotion,EditorialHeadline,Label,PaperHighlight,Annotation,PaperStamp} from '../components/Paper';
export const Keep:React.FC=()=> <>
 <PaperMotion at={37.02} stepped={false} style={{position:'absolute',left:64,top:205,width:900}}><Label>01 / KEEP WHAT WORKS</Label><div style={{position:'absolute',left:-5,top:170}}><PaperHighlight at={40.64} width={780} thickness={78}/></div><EditorialHeadline size={100} style={{position:'relative',marginTop:27}}>IF IT WORKS,<br/>KEEP IT.</EditorialHeadline></PaperMotion>
 <div style={{position:'absolute',left:100,top:520,fontSize:30,fontWeight:600,color:T.muted}}>Reliable. Useful. Making life easier.</div>
 <div style={{position:'absolute',left:295,top:850,zIndex:30}}><PaperStamp text="RELIABLE" at={40.8} color={T.semanticCheck} rotation={-11}/></div>
 <div style={{position:'absolute',left:130,top:1050,zIndex:60}}><Annotation type="check" at={43.8} width={150}height={100}color={T.semanticCheck}stroke={9}/></div>
</>;
