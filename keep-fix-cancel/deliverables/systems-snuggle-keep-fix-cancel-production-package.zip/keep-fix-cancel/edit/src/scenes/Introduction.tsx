import React from 'react';
import {T,EditorialHeadline,Label,clock,p} from '../components/Paper';
export const Introduction:React.FC=()=>{
 const t=clock();const digits=['M5 38C5 0 65 0 65 36C65 62 8 80 4 112H70','M20 2C-6 5-6 111 21 112C48 112 48 1 20 2','M5 38C5 0 65 0 65 36C65 62 8 80 4 112H70','M2 5H71L20 112'];return <>
  <div style={{position:'absolute',left:64,top:205}}><Label>YOUR SOFTWARE REVIEW</Label><EditorialHeadline size={99} style={{marginTop:27}}>BEFORE</EditorialHeadline><svg width={900}height={200}viewBox="0 0 450 115"style={{marginTop:15,overflow:'visible'}}>{digits.map((d,i)=><path key={i} d={d} transform={`translate(${i*104},0)`} stroke={T.roseDark}strokeWidth={5}fill="none"strokeLinecap="round"strokeLinejoin="round"pathLength={1}strokeDasharray={1}strokeDashoffset={1-p(t,33.12+i*.16,.55)}/>)}</svg></div>
  <div style={{position:'absolute',left:72,top:600,fontSize:27,fontWeight:600,color:T.muted,opacity:p(t,34.4)}}>Three decisions. A clearer stack.</div>
 </>;
};
