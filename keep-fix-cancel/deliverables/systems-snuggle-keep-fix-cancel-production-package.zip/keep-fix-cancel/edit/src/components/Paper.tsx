import React,{useMemo} from 'react';
import {AbsoluteFill,Easing,interpolate,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {theme as T} from '../theme';
export {T};
export const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'}as const;
export const ease=Easing.bezier(.2,.78,.2,1);
export const p=(t:number,at:number,d=.5)=>interpolate(t,[at,at+d],[0,1],{...clamp,easing:ease});
export const lerp=(a:number,b:number,q:number)=>a+(b-a)*q;
export const SourceOffset=React.createContext(0);
export const clock=()=>{const {fps}=useVideoConfig();return useCurrentFrame()/fps+React.useContext(SourceOffset);};
export const step=(t:number,rate=12)=>Math.floor(t*rate)/rate;
export const seeded=(seed:number,i:number)=>{const n=Math.sin(seed*71.13+i*17.73)*43758.5453;return n-Math.floor(n);};
export const material=(name='ivory')=>`url(${staticFile('materials/'+name+'.png')})`;
export const edgePoints=(seed:number,rough=1)=>{
 const pts:string[]=[];let n=0;
 for(let i=0;i<=20;i++)pts.push(`${i*5}% ${seeded(seed,n++)*rough}%`);
 for(let i=1;i<=20;i++)pts.push(`${100-seeded(seed,n++)*rough}% ${i*5}%`);
 for(let i=19;i>=0;i--)pts.push(`${i*5}% ${100-seeded(seed,n++)*rough}%`);
 for(let i=19;i>0;i--)pts.push(`${seeded(seed,n++)*rough}% ${i*5}%`);
 return `polygon(${pts.join(',')})`;
};
export const PaperTexture:React.FC<{kind?:string;opacity?:number}>=({kind='ivory',opacity=1})=><AbsoluteFill style={{backgroundImage:material(kind),backgroundSize:'640px 640px',opacity,pointerEvents:'none'}}/>;
export const PaperBackground:React.FC=()=> <AbsoluteFill style={{background:T.cream}}><PaperTexture kind="desk"/><div style={{position:'absolute',inset:0,boxShadow:'inset 0 0 220px rgba(71,57,52,.09)'}}/><div style={{position:'absolute',left:-100,top:1260,width:450,height:600,backgroundImage:material('halftone'),rotate:'-12deg',opacity:.45}}/><div style={{position:'absolute',right:-90,top:-70,width:330,height:390,backgroundImage:material('halftone'),rotate:'8deg',opacity:.3}}/></AbsoluteFill>;
export const TornPaper:React.FC<{children?:React.ReactNode;seed?:number;kind?:string;rough?:number;style?:React.CSSProperties;contentStyle?:React.CSSProperties;shadow?:string}>=({children,seed=1,kind='ivory',rough=1,style,contentStyle,shadow=T.shadows.rest})=>{
 const clip=useMemo(()=>edgePoints(seed,rough),[seed,rough]);
 return <div style={{filter:`drop-shadow(${shadow})`,...style}}><div style={{width:'100%',height:'100%',background:T.paper,backgroundImage:material(kind),backgroundSize:'640px 640px',clipPath:clip,position:'relative',...contentStyle}}>{children}</div></div>;
};
export type PaperMotionProps={children:React.ReactNode;at?:number;duration?:number;stepped?:boolean;direction?:'left'|'right'|'up'|'down';rotation?:number;scale?:number;intensity?:number;style?:React.CSSProperties;lift?:boolean;time?:number;shadow?:string;easing?:(x:number)=>number};
export const PaperMotion:React.FC<PaperMotionProps>=({children,at=0,duration=.55,stepped=true,direction='down',rotation=0,scale=1,intensity=1,style,lift=false,time,shadow,easing=ease})=>{
 const raw=clock();const t=stepped?step(time??raw):time??raw;const q=interpolate(t,[at,at+duration],[0,1],{...clamp,easing});const distance=110*intensity;const bump=interpolate(q,[0,.72,1],[distance,-5*intensity,0],clamp);const x=direction==='left'?-bump:direction==='right'?bump:0;const y=direction==='up'?-bump:direction==='down'?bump:0;
 return <div style={{opacity:Math.min(q*5,1),translate:`${x}px ${y}px`,rotate:`${rotation+(1-q)*3*intensity}deg`,scale:lerp(scale*.98,scale,q),filter:shadow?`drop-shadow(${shadow})`:lift?`drop-shadow(6px ${lerp(20,8,q)}px ${lerp(15,6,q)}px rgba(71,57,52,.15))`:undefined,...style}}>{children}</div>;
};
export const StopMotionTransform=PaperMotion;
export const PaperParallax:React.FC<{depth?:number;children:React.ReactNode;style?:React.CSSProperties}>=({depth=1,children,style})=>{const t=clock();return <div style={{translate:`${Math.sin(t*.16)*2*depth}px ${Math.cos(t*.12)*2*depth}px`,...style}}>{children}</div>;};
export const EditorialHeadline:React.FC<{children:React.ReactNode;size?:number;color?:string;style?:React.CSSProperties}>=({children,size=96,color=T.ink,style})=><div style={{fontFamily:T.headline,fontWeight:800,fontSize:size,lineHeight:1.035,letterSpacing:-3.3,color,...style}}>{children}</div>;
export const Label:React.FC<{children:React.ReactNode;color?:string;style?:React.CSSProperties}>=({children,color=T.muted,style})=><div style={{fontFamily:T.body,fontSize:21,fontWeight:700,lineHeight:1.35,letterSpacing:2.2,color,...style}}>{children}</div>;
export const PaperLabel:React.FC<{children:React.ReactNode;dark?:boolean;style?:React.CSSProperties}>=({children,dark=false,style})=><div style={{display:'inline-block',background:dark?T.ink:T.roseDark,backgroundImage:material(dark?'dark':'rose'),padding:'12px 20px',color:T.paper,fontSize:26,fontWeight:800,letterSpacing:1,...style}}>{children}</div>;
export const PaperHighlight:React.FC<{width:number;at:number;duration?:number;color?:string;thickness?:number;time?:number}>=({width,at,duration=.65,color=T.rose,thickness=48,time})=>{const t=clock();return <svg width={width} height={thickness+14} style={{overflow:'visible'}}><defs><clipPath id={`hl-${width}-${at}`}><rect width={width*p(time??t,at,duration)} height={thickness+14}/></clipPath></defs><path clipPath={`url(#hl-${width}-${at})`} d={`M4 8L${width*.3} 4L${width*.62} 8L${width-5} 3L${width-1} ${thickness}L${width*.7} ${thickness+4}L${width*.3} ${thickness}L3 ${thickness+7}Z`} fill={color} opacity={.48}/></svg>;};
export const HandDrawnHighlight=PaperHighlight;
export const Annotation:React.FC<{type?:'circle'|'underline'|'arrow'|'check'|'bracket';width?:number;height?:number;at:number;duration?:number;color?:string;stroke?:number;time?:number}>=({type='underline',width=600,height=80,at,duration=.65,color=T.roseDark,stroke=6,time})=>{
 const t=clock();const paths={underline:`M5 ${height*.6}Q${width*.4} ${height*.2} ${width-6} ${height*.46}`,circle:`M${width*.92} ${height*.2}C${width*.5} ${-height*.07} 5 0 4 ${height*.48}C-6 ${height*.95} ${width*.8} ${height*1.13} ${width-6} ${height*.57}C${width+16} ${height*.18} ${width*.65} 0 ${width*.5} 7`,arrow:`M5 ${height*.8}Q${width*.5} -10 ${width-12} ${height*.35}m-30 -30 30 30-40 14`,check:`M8 ${height*.47}L${width*.37} ${height*.85}L${width-8} 8`,bracket:`M${width*.8} 5H10V${height-6}H${width*.8}`};
 return <svg width={width} height={height} style={{overflow:'visible'}}><path d={paths[type]} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1-p(time??t,at,duration)}/></svg>;
};
export const HandDrawnArrow:React.FC<React.ComponentProps<typeof Annotation>>=props=><Annotation {...props} type="arrow"/>;
export const PaperStamp:React.FC<{text:string;at:number;color?:string;rotation?:number;style?:React.CSSProperties}>=({text,at,color=T.roseDark,rotation=-8,style})=>{
 const t=step(clock());const q=p(t,at,.24);const scale=interpolate(q,[0,.65,1],[1.3,.97,1],clamp);
 return <div style={{position:'relative',opacity:Math.min(q*4,1),scale,rotate:`${rotation}deg`,display:'inline-block',border:`5px solid ${color}`,padding:'10px 16px',fontWeight:800,fontSize:40,letterSpacing:1,color,...style}}>{text}<div style={{position:'absolute',inset:2,border:`1px solid ${color}`,opacity:.5}}/></div>;
};
export const Icon:React.FC<{kind:string;size?:number;color?:string}>=({kind,size=48,color=T.ink})=>{
 const paths:Record<string,React.ReactNode>={
  crm:<><rect x="4" y="8" width="40" height="33" rx="2"/><circle cx="17" cy="20" r="5"/><path d="M9 34q8-13 16 0M31 18h7M31 26h7M31 33h7"/></>,
  email:<><path d="M4 10h40v29H4Z"/><path d="m4 11 20 16 20-16"/></>,
  automation:<><path d="M8 8h12v12H8ZM29 29h12v12H29ZM20 14h15v15M14 20v15h15"/><path d="m31 25 4 5 4-5M25 31l5 4-5 4"/></>,
  projects:<><path d="M5 9h38v33H5ZM5 18h38M17 18v24M30 18v24M10 24h3M22 29h4M34 24h4"/></>,
  booking:<><rect x="5" y="9" width="38" height="34" rx="2"/><path d="M5 19h38M14 3v12M34 3v12m-20 17 7 6 13-14"/></>,
  files:<><path d="M3 13h16l4 5h22l-5 25H4ZM4 13V7h16l5 6h17v5"/></>,
  cursor:<path d="M9 4v34l9-10 8 16 7-4-9-15 14-2Z"/>,
  clock:<><circle cx="24" cy="24" r="20"/><path d="M24 11v14l10 5"/></>,
  person:<><circle cx="24" cy="14" r="9"/><path d="M5 45c0-25 38-25 38 0"/></>,
  form:<><path d="M9 3h30v42H9Z"/><path d="M16 13h16M16 22h16M16 31h9"/></>,
  toy:<><path d="M5 24h19v19H5ZM14 19 25 3l11 16Z"/><circle cx="35" cy="33" r="10"/></>,
 };
 return <svg width={size} height={size} viewBox="0 0 48 48" fill="none" stroke={color} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">{paths[kind]??paths.form}</svg>;
};
export const PaperCutout=Icon;
export const Tape:React.FC<{style?:React.CSSProperties;seed?:number}>=({style,seed=80})=><div style={{width:135,height:43,background:'rgba(231,216,208,.7)',backgroundImage:material('kraft'),clipPath:edgePoints(seed,5),opacity:.85,rotate:'-7deg',...style}}/>;
export const PaperChecklist:React.FC<{items:string[];at:number;style?:React.CSSProperties}>=({items,at,style})=>{
 const t=clock();return <div style={style}>{items.map((s,i)=><div key={s} style={{display:'flex',alignItems:'center',gap:22,fontSize:31,fontWeight:600,padding:'24px 0',borderBottom:`1px solid ${T.line}`,opacity:p(t,at+i*.38)}}><div style={{width:28,height:28,border:`3px solid ${T.roseDark}`,flexShrink:0}}/>{s}</div>)}</div>;
};

export const PaperCard=TornPaper;
