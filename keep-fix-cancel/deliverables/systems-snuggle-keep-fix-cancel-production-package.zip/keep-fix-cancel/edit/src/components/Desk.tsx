import React from 'react';
import {staticFile} from 'remotion';
import {T,TornPaper,PaperMotion,Icon,clock,p,lerp,step} from './Paper';
export const appNames=['CRM','EMAIL','AUTOMATION','PROJECTS','BOOKING','FILES'];
const appKinds=['crm','email','automation','projects','booking','files'];
type Pose={x:number;y:number;s:number;r:number;opacity?:number};
const initial:Pose[]=[{x:100,y:650,s:1,r:-6},{x:560,y:610,s:1,r:7},{x:220,y:880,s:1,r:-4},{x:650,y:920,s:1,r:6},{x:95,y:1160,s:1,r:-5},{x:520,y:1190,s:1,r:4}];
const blend=(a:Pose,b:Pose,q:number):Pose=>({x:lerp(a.x,b.x,q),y:lerp(a.y,b.y,q),s:lerp(a.s,b.s,q),r:lerp(a.r,b.r,q),opacity:lerp(a.opacity??1,b.opacity??1,q)});
export const SoftwareCard:React.FC<{label:string;kind:string;seed:number;children?:React.ReactNode;style?:React.CSSProperties;small?:boolean}>=({label,kind,seed,children,style,small=false})=><TornPaper seed={seed} rough={1.15} style={{width:300,height:240,...style}} contentStyle={{padding:24}}><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',borderBottom:`2px solid ${T.ink}`,paddingBottom:15}}><Icon kind={kind} size={40}/><span style={{fontSize:label.length>9?23:29,fontWeight:800,letterSpacing:-.8}}>{label}</span></div>{children??<><div style={{marginTop:24,height:5,width:'82%',background:T.line}}/><div style={{marginTop:15,height:5,width:'65%',background:T.line}}/><div style={{marginTop:15,height:5,width:'73%',background:T.line}}/>{!small&&<div style={{marginTop:22,fontSize:15,letterSpacing:2,fontWeight:700,color:T.muted}}>SOFTWARE / EXAMPLE</div>}</>}</TornPaper>;

export const appPose=(i:number,t:number):Pose=>{
 let a={...initial[i]};const hand=step(t);
 if(t>=11.26){const grid={x:i%2?590:90,y:600+Math.floor(i/2)*280,s:1.02,r:i%2?.6:-.5};a=blend(a,grid,p(hand,11.26,.7));if(t>17)a=blend(a,{...grid,x:grid.x+(i%2?18:-12),y:grid.y+(i%2?-10:10),r:(i%2?1:-1)*(3+i*.3)},p(hand,17,.8));}
 if(t>=33.6)a=blend(a,{x:70+i*145,y:650+(i%2)*24,s:.52,r:i%2?3:-3},p(hand,33.6,.5));
 if(t>=37.02&&t<47.38){
  let target:Pose=i===4?{x:150,y:680,s:1.15,r:-2}:i===5?{x:365,y:790,s:1.05,r:2}:{x:760,y:450+i*96,s:.64,r:i%2?3:-3,opacity:.42};
  a=blend(a,target,p(hand,37.02,.6));
  if(i===4||i===5)a=blend(a,{...target,y:i===4?1060:1150,r:i===4?-1:1},p(hand,i===4?42:43.2,.9));
 }
 if(t>=47.38&&t<59.36){
  const from=appPose(i,47.37);const target:Pose=i===0?{x:585,y:640,s:1.34,r:1}:i===2?{x:650,y:1110,s:.74,r:-2}:i===4||i===5?{x:100+(i-4)*60,y:1240,s:.5,r:1}:{x:100+(i-1)*30,y:1280,s:.62,r:i%2?3:-3,opacity:.45};
  a=blend(from,target,p(hand,47.38,.6));
  if(i===0||i===2)a=blend(a,{...target,y:i===0?1280:1320,s:.65,opacity:1},p(hand,58.65,.55));
 }
 if(t>=59.36&&t<75.82){
  const from=appPose(i,59.35);const target:Pose=i===1?{x:125,y:1080,s:.85,r:-3}:i===3?{x:620,y:1120,s:.85,r:3}:i===4||i===5?{x:85+(i-4)*40,y:1280,s:.48,r:1}:{x:790,y:1240+(i===2?40:0),s:.48,r:-1};
  a=blend(from,target,p(hand,59.36,.65));if(i===1||i===3)a={...a,y:a.y+lerp(0,45,p(Math.min(hand,70.98),69.8,.7))};
 }
 if(t>=75.82){
  const from=appPose(i,75.81);const group=i===4||i===5?0:i===0||i===2?1:2;const pair=i===5||i===2||i===3?1:0;
  a=blend(from,{x:90+group*315+pair*55,y:1100+pair*58,s:.6,r:pair?2:-2},p(hand,75.82,.85));
 }
 if(t>=82.52)a={...a,y:a.y+450*p(t,82.52,.7),opacity:(a.opacity??1)*(1-p(t,82.52,.7))};
 return a;
};
export const SoftwareDeck:React.FC=()=>{
 const t=clock();const visible=t<21.54?1:t<33.6?1-p(t,21.54,.35):p(t,33.6,.4);const caution=t>=70.98&&t<75.82?.25:1;
 return <>{appNames.map((name,i)=>{
  const a=appPose(i,t);const fix=t>=47.38&&t<58.5&&i===0;const fill=t<55?p(t,52.4,.4):p(t,57,.4);
  return <div key={name} style={{position:'absolute',left:a.x,top:a.y,width:300,height:240,scale:a.s,rotate:`${a.r}deg`,transformOrigin:'top left',opacity:visible*(a.opacity??1)*caution,zIndex:10+i}}><PaperMotion at={.7+i*.3} duration={.4} direction="up" rotation={0} intensity={.8}><SoftwareCard label={name} kind={appKinds[i]} seed={70+i*13}>{fix?<><div style={{fontSize:18,color:T.muted,marginTop:18}}>CONTACT RECORD</div><div style={{fontSize:23,fontWeight:700,marginTop:12}}>{'Alex Morgan'.slice(0,Math.round(fill*11))}</div><div style={{fontSize:18,marginTop:9}}>{'alex@example.com'.slice(0,Math.round(fill*16))}</div><div style={{marginTop:13,fontSize:16,fontWeight:800,color:T.roseDark}}>{fill>.9?'RECORD UPDATED':'WAITING FOR DETAILS'}</div></>:undefined}</SoftwareCard></PaperMotion></div>;
 })}</>;
};

type FolderPose={x:number;y:number;w:number;h:number};
export const folderPose=(i:number,t:number):FolderPose=>{
 let a={x:70+i*315,y:830,w:290,h:550};
 const blendF=(b:FolderPose,q:number)=>{a={x:lerp(a.x,b.x,q),y:lerp(a.y,b.y,q),w:lerp(a.w,b.w,q),h:lerp(a.h,b.h,q)};};
 if(t>=37.02&&t<47.38)blendF(i===0?{x:75,y:680,w:620,h:740}:i===1?{x:760,y:680,w:240,h:300}:{x:760,y:1080,w:240,h:300},p(step(t),37.02,.65));
 if(t>=47.38&&t<59.36){a=folderPose(i,47.37);blendF(i===1?{x:70,y:1080,w:940,h:360}:i===0?{x:75,y:1160,w:230,h:260}:{x:775,y:1160,w:230,h:260},p(step(t),47.38,.6));}
 if(t>=59.36&&t<75.82){a=folderPose(i,59.35);blendF(i===2?{x:75,y:1080,w:930,h:360}:i===0?{x:75,y:1160,w:230,h:260}:{x:775,y:1160,w:230,h:260},p(step(t),59.36,.6));}
 if(t>=75.82){a=folderPose(i,75.81);blendF({x:70+i*315,y:1050,w:290,h:410},p(step(t),75.82,.85));}
 if(t>=82.52)a={...a,y:a.y+450*p(t,82.52,.7)};
 return a;
};
export const PaperFolder:React.FC<{index:number;front?:boolean}>=({index:i,front=false})=>{
 const t=clock();if(t<33.7)return null;const a=folderPose(i,t);const q=p(step(t),33.96+i*.12,.5)*(1-p(t,82.52,.7));const active=(i===0&&t>=37.02&&t<47.38)||(i===1&&t>=47.38&&t<59.36)||(i===2&&t>=59.36&&t<75.82);const names=['KEEP','FIX','CANCEL'];const color=i===0?T.line:i===1?T.rose:T.ink;const caut=t>=70.98&&t<75.82?.25:1;
 return <div style={{position:'absolute',left:a.x,top:a.y,width:a.w,height:a.h,opacity:q*caut,translate:`0px ${(1-q)*150}px`,rotate:`${(i-1)*-.6}deg`,zIndex:front?(active?45:40):2,filter:`drop-shadow(5px ${front?8:13}px 8px rgba(71,57,52,.15))`,pointerEvents:'none'}}>
  {!front?<svg width="100%" height="100%" viewBox="0 0 400 400" preserveAspectRatio="none"><defs><pattern id={'fp'+i}width={640}height={640}patternUnits="userSpaceOnUse"><image href={staticPattern(i)} width={640} height={640}/></pattern></defs><path d="M4 33L21 31L25 8L172 5L188 34L394 31L396 394L4 397Z" fill={color}/><path d="M4 33L21 31L25 8L172 5L188 34L394 31L396 394L4 397Z" fill={`url(#fp${i})`} opacity={.5}/><path d="M25 8 172 5 188 34" stroke={i===2?T.rose:T.muted} strokeWidth={1} fill="none" opacity={.4}/></svg>:
   <><svg width="100%" height="100%" viewBox="0 0 400 400" preserveAspectRatio="none"><defs><pattern id={'ffp'+i}width={640}height={640}patternUnits="userSpaceOnUse"><image href={staticPattern(i)}width={640}height={640}/></pattern></defs><path d={`M4 ${active?182:156}L53 ${active?179:153}L102 ${active?184:158}L168 ${active?180:155}L224 ${active?184:158}L295 ${active?179:154}L396 ${active?183:157}L393 393L6 397Z`} fill={color}/><path d={`M4 ${active?182:156}L53 ${active?179:153}L102 ${active?184:158}L168 ${active?180:155}L224 ${active?184:158}L295 ${active?179:154}L396 ${active?183:157}L393 393L6 397Z`}fill={`url(#ffp${i})`}opacity={.65}/><path d="M9 394H391" stroke={i===2?T.roseDark:T.muted} strokeWidth={3} opacity={.4}/></svg><div style={{position:'absolute',left:'9%',right:'8%',top:active?'62%':'58%',fontFamily:T.headline,fontWeight:800,fontSize:Math.min(a.w*.15,100),letterSpacing:-2,color:i===2?T.paper:T.ink}}>{names[i]}</div>{i===2&&a.w>500&&<div style={{position:'absolute',left:'9%',top:'88%',fontSize:20,fontWeight:700,color:T.rose,letterSpacing:1}}>REVIEW BEFORE YOU CANCEL</div>}</>}
 </div>;
};
const staticPattern=(i:number)=>staticFile('materials/'+(i===0?'kraft':i===1?'rose':'dark')+'.png');
