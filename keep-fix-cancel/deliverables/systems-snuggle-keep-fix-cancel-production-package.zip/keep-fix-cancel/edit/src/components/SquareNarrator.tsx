import React from 'react';
import {Video} from '@remotion/media';
import {staticFile,useVideoConfig} from 'remotion';
import {T,TornPaper,Tape,clock,p} from './Paper';
export const SquareNarrator:React.FC<{x:number;y:number;size?:number;start:number;end:number;rotation?:number;seed?:number}>=({x,y,size=270,start,end,rotation=-1.4,seed=19})=>{
 const t=clock();const {fps}=useVideoConfig();if(t<start-.2||t>end+.25)return null;const q=p(t,start,.25)*(1-p(t,end,.2));
 return <div style={{position:'absolute',left:x,top:y,width:size,height:size,opacity:q,rotate:`${rotation}deg`,translate:`0px ${(1-q)*20}px`}}><TornPaper seed={seed} rough={1.8} style={{width:'100%',height:'100%'}} contentStyle={{padding:8}}><Video src={staticFile('narrator-square.mp4')} muted objectFit="cover" premountFor={fps} style={{width:'100%',height:'100%'}}/></TornPaper><Tape seed={seed+4} style={{position:'absolute',left:size*.28,top:-15,backgroundColor:T.line}}/></div>;
};
