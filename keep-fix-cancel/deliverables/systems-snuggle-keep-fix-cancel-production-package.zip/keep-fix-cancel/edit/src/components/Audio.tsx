import React from 'react';
import {Audio} from '@remotion/media';
import {staticFile,useVideoConfig,interpolate} from 'remotion';
import {clamp} from './Paper';
export const MusicTrack:React.FC<{file:string;gain:number}>=({file,gain})=>{
 const {fps,durationInFrames}=useVideoConfig();if(!file)return null;
 return <Audio src={staticFile(file)} premountFor={fps}volume={f=>{const t=f/fps;const duck=t>6.8&&t<10.7?.5:t>21.5&&t<33.9?.65:t>70.98&&t<75.08?.6:1;return gain*duck*interpolate(f,[0,fps,durationInFrames-fps,durationInFrames],[0,1,1,0],clamp);}}/>;
};
export const SoundEffectCue:React.FC<{gain:number}>=({gain})=>{const {fps}=useVideoConfig();return <Audio src={staticFile('foley.wav')}volume={gain}premountFor={fps}/>;};
