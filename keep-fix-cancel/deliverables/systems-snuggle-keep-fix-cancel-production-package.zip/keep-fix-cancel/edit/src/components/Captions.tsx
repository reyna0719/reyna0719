import React from 'react';
import type {Caption} from '@remotion/captions';
import {T,clock} from './Paper';
export const CaptionOverlay:React.FC<{captions:Caption[]}>=({captions})=>{
 const t=clock()*1000;const cue=captions.find(c=>t>=c.startMs&&t<c.endMs);if(!cue)return null;
 const parts=cue.text.split(/(software|more tools|time|2027|Keep|fix|cancel|data|integrations|working for you)/gi);
 return <div style={{position:'absolute',left:64,right:124,top:1510,minHeight:115,zIndex:120,display:'flex',justifyContent:'center',alignItems:'center'}}><div style={{fontFamily:T.body,fontSize:38,lineHeight:1.3,fontWeight:600,textAlign:'center',whiteSpace:'pre-line',color:T.ink,background:'rgba(255,253,251,.93)',padding:'16px 22px',boxShadow:`-5px 0 0 ${T.roseDark}`}}>{parts.map((s,i)=><span key={i}style={{fontWeight:i%2?800:600,color:i%2?T.roseDark:T.ink}}>{s}</span>)}</div></div>;
};
