import {loadFont} from '@remotion/fonts';
import {staticFile} from 'remotion';
export const fontsReady=Promise.all([
 loadFont({family:'Tenor Sans',url:staticFile('fonts/TenorSans-400.ttf'),weight:'400'}),
 ...['400','500','600','700','800'].map(weight=>loadFont({family:'Montserrat',url:staticFile(`fonts/Montserrat-${weight}.ttf`),weight})),
]);
