# Brand and assets

The live https://systemsnsnuggle.com/ homepage CSS was checked on October 29,
2026. The production uses its #F7EEE8 cream, #FFFDFB paper, #C98F7B rose,
#AD705E dark rose, #473934 brown, #83736C muted ink and #E7D8D0 line color.
These are centralized in `src/theme.ts`. Montserrat and Tenor Sans are bundled
locally from the prior verified brand setup with their font-license texts.

The muted green #596951 is a functional annotation color for the explicitly
requested KEEP checkmark. It is labeled as a semantic illustration token, not
an official brand color.

Paper materials are original seeded grain/fibre/halftone textures generated for
this project. Edges use seeded irregular geometry, not repeated identical tears.
Cards persist with the same material identity across scenes. Paper folders,
icons, calendar, cutouts, receipts and marks are original vector illustrations.
All contact details are fictional and use example.com. No third-party product
logos, Vox marks, proprietary sequences, stock family footage or generated
family photographs are used.

Original video: the supplied Edit Phase 1.mp4, retrieved using Google Drive file
160StxNq0y1NYIrN3of-CHM4Tag4XB1I8. Original video and SRT are preserved separately.
The reusable narrator proxy is a 480px square at the original 30fps, larger than
the 300px maximum displayed portrait. It has no audio track, and its crop was
checked in the actual scene previews. Voice is a separate timing-preserving WAV.
No face is fabricated, redrawn or lip-synced.
