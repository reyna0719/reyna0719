# Music and sound

The delivered mix uses the original narrator and 29 original procedural foley
cues. No licensed music was supplied, so music is disabled; no track or license
is invented. `sound-effects-cue-sheet.csv` lists the actual source-relative cues.
They include restrained paper drops, card movement, typing, marker strokes,
folder placement, mouse clicks and rubber stamps. Effects are sparse and do not
play on every object. There are no sampled libraries, artificial baby sounds,
loud memes, vocals or aggressive advertisement music.

The original voice is processed without changing timing, pitch or accent.
Two-pass normalization targets -16 LUFS and -1.5 dBTP. The final QA report gives
measurements of the encoded mix, which may differ slightly after AAC encoding.

## Optional music plan (not an included track)

| Source seconds | Suggested licensed instrumental treatment |
|---|---|
| 0–11.26 | Curious minimal documentary groove; dip under the boss joke |
| 11.26–21.54 | Restrained documentary pulse |
| 21.54–32.18 | Softer, warmer texture |
| 32.18–37.02 | Brief folder transition |
| 37.02–47.38 | Calm and reassuring |
| 47.38–59.36 | Light procedural rhythm, then a small sense of discovery |
| 59.36–70.98 | Playful, controlled paper movement |
| 70.98–75.82 | Settle and duck for the caution |
| 75.82–82.52 | Warm resolution |
| 82.52–end | Restrained curiosity; gentle close |

A future rights-cleared local music file can be selected with `musicFile`.
`MusicTrack` provides head/tail fades and narrative dips. Recheck the mix after
adding music; the default gain is not a verified loudness measurement.
