# Before 2027: KEEP, FIX or CANCEL your business tools

1080×1920, 30 fps, 2,635 frames, 87.833 seconds. No internal cuts or speed changes. Source and edited clocks share zero.

| Scene | Source / edited seconds | Visual story |
|---|---|---|
| opening | 0.00–11.26 | Invoice and the same six paper software cards; repeated manual transfers, boss label and selective square portrait. |
| expertise | 11.26–21.54 | Cards organize then become disconnected; more tools headline, drawn warnings and additional clippings. |
| personal | 21.54–32.18 | Paper calendar, clock and toy/stroller metaphor; square narrator for personal warmth and expression. |
| folders | 32.18–37.02 | Handwritten BEFORE 2027 follows verified spoken phrase; three physical folders settle into place. |
| keep | 37.02–47.38 | KEEP folder opens; generic booking/files examples receive a reliable stamp and drawn green check, then file away. |
| fix | 47.38–59.36 | Same CRM card joins a contact-form illustration; two manual transfers become a drawn configured flow. Both documents file away after the sentence. |
| cancel | 59.36–70.98 | Receipts and overlapping-function examples; duplication circled and REVIEW stamp applied. No deletion or account cancellation. |
| check | 70.98–75.82 | Cancellation motion pauses; neutral unchecked backup/integration/workflow checklist takes focus. |
| takeaway | 75.82–82.52 | Same stack organized into three folders; three review questions connect the stack to the main takeaway during a smooth pullback. |
| teaser | 82.52–87.83 | Fresh sheet, square narrator and understated teaser; unfinished spoken sentence preserved. |

The supplied brief placed the year transition at 33.96s. Local recognition identifies “So before” at about 32.18s and “2027” at 33.18–34.02s, so the drawn date begins on that phrase and the folder movement follows. The source SRT timing remains the caption basis; cues are not treated as exact word onsets.

The recurring cards are generic illustrative categories, not a verified client software stack. KEEP/FIX/CANCEL sorting illustrates evaluation, not actual software changes. The CANCEL folder holds review candidates; no account is cancelled or file erased.

The FIX connector begins drawing at 56.08s, with packet movement at 56.65s and record completion near 57.4s. Cards file at 58.65s after the thought has completed. The manual copies use 51.48s and 53.00s. These cues are informed by recognized audio words, not uniformly spaced subtitle intervals.

Narrator portraits are 250–300px square (23.1–27.8% of canvas width), appear selectively, and remain 30fps. Their source windows are approximately 6.98–10.7s, 11.26–15.3s, 22.15–27.8s, 29.9–31.9s, and 82.52s–end. All original narration continues when her image is absent.
