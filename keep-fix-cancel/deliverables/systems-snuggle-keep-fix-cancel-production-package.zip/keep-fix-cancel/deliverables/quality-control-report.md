# Final quality-control report

Project: Before 2027, Keep, Fix or Cancel Your Business Tools — Systems & Snuggle.

## Export

| Check | Verified result |
|---|---|
| Picture | H.264, 1080×1920, yuv420p |
| Frame rate/count | 30 fps, 2635 frames |
| Video duration | 87.833333 seconds |
| Container duration | 87.851000 seconds |
| Audio | AAC, 48000 Hz, 2 channels |
| Integrated loudness | -16.0 LUFS |
| True peak | -1.4 dBTP, below clipping |
| Full-file decode | Passed, no reported errors |
| Black segments | None detected at a 0.1-second minimum duration |
| Streaming layout | Fast-start MP4, moov before mdat |
| TypeScript | Typecheck passed |

## Source and transcript

The original MP4 and SRT remain unchanged, verified by SHA-256. The full source
recording is retained in the edit, with no internal cuts or speed changes.
The last spoken sentence remains unfinished. No voice was synthesized, rewritten,
redubbed, pitch-shifted or continued.

All original spoken caption words are preserved after punctuation/case normalization.
The corrected SRT contains 31 pages, all positive in duration, chronologically
ordered, non-overlapping, within the source range and at most two lines each.
The widest 38px caption line, including bold emphasis, measures 772.2px
against 848px of available text width. The transcript was cross-checked using
local speech recognition. Original phrases such as “babysitting a software” and
“apps that's doing” remain as recorded rather than being silently rewritten.

The date transition begins on the verified spoken phrase around 32.18s; the
written year follows its recognized 33.18–34.02s span. Cue timings are not treated
as exact word timings. The original SRT stays the caption timing basis.

Waveform comparison of decoded export audio with the processed source at
2, 18, 31, 52, 72 and 85 seconds found **0 ms offset at all six points**.
The measured correlations and original source hashes are retained in reports/.

## Visual review

Actual encoded frames were extracted for the opening, boss joke, expertise,
motherhood, software-stroller metaphor, folder introduction, KEEP, both FIX
states, CANCEL review, caution checklist, final takeaway and teaser. Additional
frames check the cards after filing. Eight encoded transition samples examine
the manual transfers, connector reveal, automatic packet, record update and
final filing. The FIX section was also rendered as a separate motion draft.

The presenter appears selectively in square 250–300px paper/photo windows.
The 480px square local derivative retains the source's 30fps playback and has
no audio track. Its crop is reviewed for face framing, and it exceeds the largest
300px display window. Original full-frame media remains preserved separately.
Narration continues independently while the portrait is hidden, without duplicate audio.

The same software cards recur and file into three folders. Seeded fibrous paper,
irregular edges, tapes, restrained shadows, hand-drawn strokes and selected
12-update-per-second paper moves establish the tactile visual style. Camera,
connector, annotation and narrator movement remains smooth at 30fps.
Inspected frames show consistent typography, verified brand colors, intact
icons, no missing local assets, readable primary text and no portrait/important-text
obstruction. Caption space stays separate from the diagrams.

The cancellation scene marks examples for review; it does not erase data or
perform actual account cancellations. The backup/integration/workflow checklist
is intentionally unchecked. All illustrated app categories and records are
hypothetical, with example.com contact details. No savings, actual stack evidence,
client results, testimonials, universal integration guarantees or completed backups
are invented. The paper stroller is a brief visual joke, with no artificial baby
sounds or family footage. No Vox logo, copied sequence or proprietary graphic is used.

## Sound and remaining limits

There are 29 sparse original procedural foley cues and no third-party samples.
No licensed music was supplied, so music is omitted; the optional track is disabled
and has a documented replacement/mix workflow. No music license is fabricated.
The encoded mix measurements above verify levels and peaks, not a human audition.

Review used actual scene/transition frames, full-file decode, waveform timing,
caption checks and audio meters. A human listening pass and social-platform
upload/transcoding test were not performed in this environment. Interface overlays
vary by platform; the lower region is reserved and primary information is kept above it.

The editable project includes all local render assets, including the square
narrator derivative and source voice. The 159MB original full-frame input is
preserved in the workspace and identified by its source reference and hash;
it is not duplicated into the portable project archive.
